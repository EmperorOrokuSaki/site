import{l as o,a as r}from"../chunks/DYm1l7y5.js";export{o as load_css,r as start};
