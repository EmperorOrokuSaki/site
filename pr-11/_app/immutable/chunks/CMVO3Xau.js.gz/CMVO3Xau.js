import"./D76UiJao.js";import{I as c,s as l}from"./8OUupc2z.js";import{J as i,K as d,a as $}from"./BDB46AmI.js";import{l as p,b as f}from"./BRySVreV.js";function v(t,o){const r=p(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"m12 19-7-7 7-7"}],["path",{d:"M19 12H5"}]];c(t,f({name:"arrow-left"},()=>r,{get iconNode(){return s},children:(n,m)=>{var e=i(),a=d(e);l(a,o,"default",{}),$(n,e)},$$slots:{default:!0}}))}function y(t,o){const r=p(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["circle",{cx:"12",cy:"12",r:"10"}],["polyline",{points:"12 6 12 12 16 14"}]];c(t,f({name:"clock"},()=>r,{get iconNode(){return s},children:(n,m)=>{var e=i(),a=d(e);l(a,o,"default",{}),$(n,e)},$$slots:{default:!0}}))}export{v as A,y as C};
