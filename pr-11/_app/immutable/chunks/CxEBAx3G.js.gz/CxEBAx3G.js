import{b as p,E as t}from"./BDB46AmI.js";import{B as c}from"./D76UiJao.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
