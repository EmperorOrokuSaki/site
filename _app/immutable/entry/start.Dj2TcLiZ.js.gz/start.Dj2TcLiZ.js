import{l as o,a as r}from"../chunks/UM8Gv5ho.js";export{o as load_css,r as start};
