import{l as o,a as r}from"../chunks/DYXg4KRN.js";export{o as load_css,r as start};
