import{l as o,a as r}from"../chunks/ChmC28Lo.js";export{o as load_css,r as start};
