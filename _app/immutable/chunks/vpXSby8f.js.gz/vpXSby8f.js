import{e as c,a as l}from"./CsK9cus2.js";import"./DYLBypQw.js";import{L as i}from"./BxQn33wt.js";import{I as d,a as $}from"./YriMvl0X.js";import{l as p,s as m}from"./p3D-a3f0.js";function y(t,o){const r=p(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"m12 19-7-7 7-7"}],["path",{d:"M19 12H5"}]];d(t,m({name:"arrow-left"},()=>r,{get iconNode(){return s},children:(a,f)=>{var e=c(),n=i(e);$(n,o,"default",{}),l(a,e)},$$slots:{default:!0}}))}function N(t,o){const r=p(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["circle",{cx:"12",cy:"12",r:"10"}],["polyline",{points:"12 6 12 12 16 14"}]];d(t,m({name:"clock"},()=>r,{get iconNode(){return s},children:(a,f)=>{var e=c(),n=i(e);$(n,o,"default",{}),l(a,e)},$$slots:{default:!0}}))}export{y as A,N as C};
