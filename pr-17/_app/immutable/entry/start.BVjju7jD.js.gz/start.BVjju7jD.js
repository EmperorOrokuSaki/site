import{l as o,a as r}from"../chunks/CCQ7uoON.js";export{o as load_css,r as start};
